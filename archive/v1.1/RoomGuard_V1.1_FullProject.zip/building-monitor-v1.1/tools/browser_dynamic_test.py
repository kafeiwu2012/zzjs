"""Frontend tests use the explicitly labelled demo server, not physical sensors."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
out=Path('artifacts/v1.1');out.mkdir(parents=True,exist_ok=True);errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
 # Reset the demo fixture so reruns do not inherit a previous active/muted alarm.
 token=page.request.post('http://127.0.0.1:8080/api/login',data={'username':'admin','password':'DemoOnly-123456'}).json()['token']
 headers={'Authorization':'Bearer '+token}
 for device in ['room101-esp32','room102-esp8266']:
  page.request.post('http://127.0.0.1:8080/api/nodes/'+device+'/config',data={'clear_seconds':1},headers=headers)
  page.request.post('http://127.0.0.1:8080/api/demo/'+device,data={'smoke':False,'flame':False},headers=headers)
 import time
 deadline=time.monotonic()+10
 while any(n['state'].get('active') for n in page.request.get('http://127.0.0.1:8080/api/status').json()['nodes']):
  assert time.monotonic()<deadline
  page.wait_for_timeout(500)
 page.goto('http://127.0.0.1:8080');page.wait_for_selector('.sparkline');assert page.locator('.room').count()==2
 page.wait_for_timeout(4500)
 before=page.locator('.sparkline path').nth(1).get_attribute('d');page.wait_for_timeout(2500);after=page.locator('.sparkline path').nth(1).get_attribute('d');assert before!=after
 page.click('#motionToggle');assert 'reduce-motion' in page.locator('html').get_attribute('class')
 before=after;page.wait_for_timeout(2500);assert page.locator('.sparkline path').nth(1).get_attribute('d')!=before
 page.click('#motionToggle');page.screenshot(path=str(out/'动态界面_电脑.png'),full_page=True)
 page.click('#loginOpen');page.fill('#password','DemoOnly-123456');page.click('#loginForm button[type=submit]');page.wait_for_selector('#logout:visible')
 page.click('[data-action=demo][data-device=room101-esp32]');page.wait_for_selector('.room.alarm')
 page.on('dialog',lambda d:d.accept());page.click('[data-action=silence][data-device=room101-esp32]');page.wait_for_timeout(2500);assert '本次蜂鸣已消音' in page.locator('.room').first.inner_text()
 page.screenshot(path=str(out/'动态界面_告警.png'),full_page=True)
 page.route('**/api/status',lambda r:r.abort());page.wait_for_selector('html.connection-lost');frozen=page.locator('.sparkline path').nth(1).get_attribute('d');page.wait_for_timeout(2400);assert frozen==page.locator('.sparkline path').nth(1).get_attribute('d');assert page.locator('[data-action=silence]').first.is_disabled()
 page.screenshot(path=str(out/'动态界面_断线冻结.png'),full_page=True)
 page.unroute('**/api/status');page.wait_for_function("!document.documentElement.className.includes('connection-lost')")
 mobile=b.new_page(viewport={'width':375,'height':812},is_mobile=True);mobile.goto('http://127.0.0.1:8080');mobile.wait_for_selector('.sparkline');assert mobile.evaluate('document.documentElement.scrollWidth<=innerWidth');mobile.screenshot(path=str(out/'动态界面_手机.png'),full_page=True)
 mobile.emulate_media(reduced_motion='reduce');assert mobile.locator('.live-dot').evaluate("e=>getComputedStyle(e).animationName")=='none'
 screen=b.new_page(viewport={'width':1920,'height':1080});screen.goto('http://127.0.0.1:8080/?screen=1');screen.wait_for_selector('.sparkline');assert not screen.locator('#loginOpen').is_visible();screen.screenshot(path=str(out/'动态界面_大屏.png'),full_page=True)
 b.close()
assert not errors,errors
report={'test_data':'explicit_DEMO','live_trend_changes':True,'motion_toggle_keeps_data_updates':True,'alarm_and_silence':True,'disconnect_freezes_trend_and_disables_controls':True,'reconnect_recovers':True,'mobile_no_horizontal_overflow':True,'reduced_motion':True,'screen_readonly':True,'script_errors':errors}
(out/'动态界面测试.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
