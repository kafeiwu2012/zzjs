from playwright.sync_api import sync_playwright
import pathlib,json
out=pathlib.Path('artifacts');out.mkdir(exist_ok=True)
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8080');page.wait_for_selector('.room');assert page.locator('.room').count()==2
 page.screenshot(path=str(out/'网页预览_桌面.png'),full_page=True)
 page.click('#loginOpen');page.fill('#password','DemoOnly-123456');page.click('#loginForm button[type=submit]');page.wait_for_selector('#logout:visible')
 page.click('[data-action=demo][data-device=room101-esp32]');page.wait_for_selector('.room.alarm')
 page.click('[data-action=confirm][data-device=room101-esp32]');page.wait_for_timeout(2300)
 page.on('dialog',lambda d:d.accept());page.click('[data-action=silence][data-device=room101-esp32]');page.wait_for_timeout(2300)
 assert '本次蜂鸣已消音' in page.locator('.room').first.inner_text()
 page.screenshot(path=str(out/'网页预览_告警.png'),full_page=True)
 page.click('[data-tab=history]');page.wait_for_timeout(500);assert page.locator('#historyTable table').count()==1
 page.screenshot(path=str(out/'网页预览_历史.png'),full_page=True)
 page.click('[data-tab=settings]');page.fill('#clear-room101-esp32','12');page.click('[data-config=room101-esp32]');page.wait_for_timeout(2500)
 assert '已生效' in page.locator('#sync-room101-esp32').inner_text()
 page.click('[data-tab=overview]');page.click('[data-action=demo][data-device=room101-esp32]')
 mobile=browser.new_page(viewport={'width':375,'height':812},is_mobile=True,device_scale_factor=1)
 mobile.goto('http://127.0.0.1:8080');mobile.wait_for_selector('.room')
 assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
 mobile.screenshot(path=str(out/'网页预览_手机.png'),full_page=True)
 screenpage=browser.new_page(viewport={'width':1920,'height':1080});screenpage.goto('http://127.0.0.1:8080/?screen=1');screenpage.wait_for_selector('.room');assert not screenpage.locator('#loginOpen').is_visible();screenpage.screenshot(path=str(out/'网页预览_大屏.png'),full_page=True)
 browser.close()
assert not errors,errors
print(json.dumps({'browser':'Chromium','errors':errors,'desktop':True,'mobile_layout':True,'screen_readonly_ui':True,'confirm_silence_config_history':True},ensure_ascii=False))
