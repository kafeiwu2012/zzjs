"""Local real-MQTT integration; requires mosquitto binary. Temporary credentials only."""
import json,os,subprocess,sys,tempfile,time,threading,pathlib
import httpx,paho.mqtt.client as mqtt
root=pathlib.Path(__file__).resolve().parents[1]
broker=os.environ.get('MOSQUITTO_BIN','mosquitto')
def wait(fn,seconds=8):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   result=fn()
   if result:return result
  except (httpx.HTTPError,KeyError,IndexError):pass
  time.sleep(.1)
 raise AssertionError('condition timeout')
with tempfile.TemporaryDirectory(prefix='rg-mqtt-') as temp:
 t=pathlib.Path(temp);passwd=t/'passwords';passwd.write_text('server:test-server\nroom101-esp32:test101\nroom102-esp8266:test102\n')
 acl=t/'acl';acl.write_text((root/'deploy/mosquitto.acl').read_text())
 cfg=t/'mosquitto.conf';cfg.write_text(f'listener 18884 127.0.0.1\nallow_anonymous false\npassword_file {passwd}\nacl_file {acl}\n')
 log=open(t/'broker.log','w');bp=subprocess.Popen([broker,'-c',str(cfg)],stdout=log,stderr=log)
 env={**os.environ,'DATA_DIR':str(t/'data'),'ADMIN_PASSWORD':'MqttTestPassword123!','MQTT_HOST':'127.0.0.1','MQTT_PORT':'18884','MQTT_USER':'server','MQTT_PASSWORD':'test-server','DISABLE_MQTT':'0','DEMO':'0'}
 slog=open(t/'server.log','w');sp=subprocess.Popen([sys.executable,'-m','uvicorn','server.app:app','--host','127.0.0.1','--port','8890'],cwd=root,env=env,stdout=slog,stderr=slog)
 clients=[]
 try:
  h=httpx.Client(base_url='http://127.0.0.1:8890',timeout=3)
  wait(lambda:h.get('/api/status').json()['broker_online'])
  token=h.post('/api/login',json={'username':'admin','password':'MqttTestPassword123!'}).json()['token'];h.headers['Authorization']='Bearer '+token
  states={}
  for d,pwd in [('room101-esp32','test101'),('room102-esp8266','test102')]:
   s={'boot':d+'-boot','seq':1,'event_id':d+'-event','active':True,'muted':False,'reasons':['flame'],'smoke':False,'flame':True,'dht_ok':True,'mq_ready':True,'temperature':25,'humidity':55,'mq_raw':120,'mq_voltage':.5,'config_version':1,'control_nonce':'test-nonce'};states[d]=s
   c=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id=d);c.username_pw_set(d,pwd)
   def connected(c,u,f,rc,props,d=d):c.subscribe('building/'+d+'/command',1);c.publish('building/'+d+'/state',json.dumps(states[d]),1)
   def message(c,u,msg,d=d):
    p=json.loads(msg.payload)
    assert p['nonce']=='test-nonce'
    if p['kind']=='silence':states[d]['muted']=True
    else:states[d]['config_version']=p['version']
    c.publish('building/'+d+'/ack',json.dumps({'id':p['id'],'status':'applied'}),1)
    states[d]['seq']+=1;c.publish('building/'+d+'/state',json.dumps(states[d]),1)
   c.on_connect=connected;c.on_message=message;c.connect('127.0.0.1',18884,15);c.loop_start();clients.append(c)
  wait(lambda:all(n['online'] and n['state'].get('active') for n in h.get('/api/status').json()['nodes']))
  # Node101 cannot publish a valid forged state for Node102.
  forged=dict(states['room102-esp8266'],seq=999,temperature=66)
  clients[0].publish('building/room102-esp8266/state',json.dumps(forged),1).wait_for_publish(2)
  time.sleep(.4);assert h.get('/api/status').json()['nodes'][1]['state']['temperature']==25
  r=h.post('/api/nodes/room101-esp32/silence',json={'event_id':'room101-esp32-event'});assert r.status_code==200,r.text
  wait(lambda:h.get('/api/status').json()['nodes'][0]['state']['muted'])
  r=h.post('/api/nodes/room102-esp8266/config',json={'clear_seconds':20});assert r.status_code==200
  wait(lambda:h.get('/api/status').json()['nodes'][1]['config_synced'])
  assert h.get('/api/status').json()['nodes'][1]['state']['active']
  clients[0].disconnect();clients[0].loop_stop()
  # Keep second node alive while checking first timeout.
  start=time.monotonic()
  while time.monotonic()-start<21:
   states['room102-esp8266']['seq']+=1;clients[1].publish('building/room102-esp8266/state',json.dumps(states['room102-esp8266']),1);time.sleep(2)
  snap=h.get('/api/status').json();assert not snap['nodes'][0]['online'] and snap['nodes'][0]['state']['active'];assert snap['nodes'][1]['online']
  assert h.post('/api/nodes/room101-esp32/silence',json={'event_id':'room101-esp32-event'}).status_code==409
  report={'real_mqtt_broker':'Mosquitto2.0.20 local test build','dual_node':True,'acl_cross_publish_blocked':True,'silence_ack':True,'config_state_ack':True,'offline_after20s':True,'offline_keeps_alarm':True,'offline_silence_rejected':True,'physical_devices':False}
  (root/'artifacts/MQTT集成测试.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
 except Exception:
  log.flush();slog.flush();print((t/'broker.log').read_text()[-3000:]);print((t/'server.log').read_text()[-3000:]);raise
 finally:
  for c in clients:c.disconnect();c.loop_stop()
  sp.terminate();bp.terminate();sp.wait(timeout=5);bp.wait(timeout=5);log.close();slog.close()
