"""V1.1 release. Includes only placeholder Arduino credentials, never local keys."""
from pathlib import Path
import hashlib,shutil,zipfile,json,re
R=Path(__file__).resolve().parents[1];O=R.parent/'deliverables';O.mkdir(exist_ok=True)
skip_dirs={'.venv','.platformio','.pio','__pycache__','.pytest_cache','.git','.github','.gradle','build','data','demo-data'}
def allowed(p):
 rel=p.relative_to(R)
 if any(v in skip_dirs for v in rel.parts) or p.suffix in {'.jks','.keystore','.pdb','.idsig','.pyc','.elf','.map'} or p.name in {'.env','.piopm','integrity.dat','SHA256SUMS_V1.1.txt'}:return False
 if p.name=='secrets.h':
  if 'arduino' not in rel.parts:return False
  t=p.read_text()
  for k in ['WIFI_SSID','WIFI_PASSWORD','MQTT_PASSWORD']:
   assert re.search(r'#define\s+'+k+r'\s+"CHANGE_ME"',t), 'Refuse to publish configured credentials: '+str(rel)
 return True
files=sorted(p for p in R.rglob('*') if p.is_file() and allowed(p))
checks=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files)
manifest=R/'artifacts/SHA256SUMS_V1.1.txt';manifest.write_text(checks)
full=O/'RoomGuard_V1.1_FullProject.zip'
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in files+[manifest]:z.write(p,'building-monitor-v1.1/'+p.relative_to(R).as_posix())
arduino=O/'RoomGuard_ArduinoIDE_ESP32_ESP8266_V1.1.zip'
with zipfile.ZipFile(arduino,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in files:
  rel=p.relative_to(R)
  if rel.parts[0]=='arduino' or rel.name.startswith('Arduino_IDE双节点烧录手册'):z.write(p,'RoomGuard_ArduinoIDE_V1.1/'+rel.as_posix())
base=O/'RoomGuard_通用基板设计草案_V1.1.zip'
with zipfile.ZipFile(base,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  rel=p.relative_to(R)
  if rel.parts[0]=='hardware' or rel.name.startswith('通用基板设计说明') or rel.name in ['build_baseboard.py','build_baseboard_pcb.py','draw_baseboard_overview.py']:z.write(p,rel.as_posix())
for f in R.joinpath('docs').glob('*V1.1*'):
 if f.is_file() and f.suffix in {'.pdf','.docx'}:shutil.copy(f,O/f.name)
for name in ['RoomGuard-Windows10-x64.exe','RoomGuard-Android5.1.apk']:shutil.copy(R/'artifacts'/name,O/(Path(name).stem+'_V1.1'+Path(name).suffix))
for name in ['动态界面_电脑.png','动态界面_大屏.png','动态界面_手机.png']:shutil.copy(R/'artifacts/v1.1'/name,O/('V1.1_'+name))
shutil.copy(R/'hardware/基板功能与电源图.svg',O/'V1.1_基板功能与电源图.svg')
for p in [full,arduino,base]:
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert not any(n.endswith('.jks') or '/.venv/' in n or '/server.env' in n for n in z.namelist())
  if p==arduino:
   for n in ['Room101_ESP32','Room102_ESP8266']:
    for f in [n+'.ino','NodeRuntime.cpp','alarm.h','secrets.h']:assert 'RoomGuard_ArduinoIDE_V1.1/arduino/'+n+'/'+f in z.namelist()
 print(p.name,p.stat().st_size)
(O/'V1.1_下载包_SHA256.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [full,arduino,base]))
print('ZIP integrity, Arduino project completeness and credential exclusion verified.')
