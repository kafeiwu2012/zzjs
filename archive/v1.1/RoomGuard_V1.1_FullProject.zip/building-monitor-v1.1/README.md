# RoomGuard V1.1 · Arduino IDE与通用基板审阅版

本版完成四项更新：Arduino IDE双节点工程；通用基板电路与机械审阅草案；面向Linux新手的树莓派全流程配置／维护手册；电脑、手机、大屏共用的动态界面。

## 从这里开始

1. `docs/Arduino_IDE双节点烧录手册.md`：设置Arduino IDE项目位置、固定版本开发板包与随包库，改各自secrets.h，通过USB上传。
2. `docs/树莓派新手配置与维护手册.md`：从写系统卡、SSH、传文件、首次安装，到节点接入、备份、维护和版本更新。
3. `docs/通用基板设计说明_V1.1.md`：电路、模块接口、VREF跳帽、AO比例与机械核验；对应hardware中的KiCad及PDF。
4. `docs/动态终端使用说明_V1.1.md`与`docs/V1.1更新与验证报告.md`：动态展示、验证结果和实际边界。

## Arduino工程

- `arduino/Room101_ESP32/Room101_ESP32.ino`
- `arduino/Room102_ESP8266/Room102_ESP8266.ino`
- Sketchbook位置设为本项目`arduino`，其中libraries含固定版本源代码和许可。
- .ino是入口，NodeRuntime.cpp包含setup()/loop()。模板凭据为CHANGE_ME，必须填写自己网络和对应节点密码后再编译上传。
- ESP32核心2.0.17；ESP8266核心3.1.2；不要求安装PlatformIO。

## 重要的基板状态

已确认每侧15针、间距2.54mm；两排针中心距和模块尺寸／脚序尚未确认。hardware是**58器件原理图＋未布线布局草案**，没有Gerber、没有ERC/DRC制造签核。排距25.4mm为布局占位，不能直接用于打板。

一块基板只装一块ESP，每个房间各用一块相同基板。模块3.3V与ESP自身3.3V不并联。USB烧录需取下ESP单独连接。后续尺寸与电气核验后再完成制造版PCB。

## 部署与更新

首次安装：`sudo bash deploy/install.sh`；已有部署更新：`sudo bash deploy/update.sh`。两者需要在目标树莓派运行，首次安装依赖需要互联网，运行核心功能不需要公网。没有远程部署到用户设备。

仅看明确标识的模拟界面：安装`server/requirements.txt`后，在项目根运行`python -m tools.run_demo`，访问http://127.0.0.1:8080，演示账号admin／DemoOnly-123456。生产安装要求自设密码，不使用演示密码。

动态趋势仅使用已收到采样，断线冻结；模拟模式才产生明确标识的演示数据。EXE依赖系统Edge，APK仍需OPPO Android5.1真机验收。原V1.0文档在docs/archive_v1.0，仅作历史参考，V1.1上述手册优先。
