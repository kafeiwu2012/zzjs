import asyncio, json, logging, os, secrets, shutil, subprocess, time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from .core import Engine, DEVICES, password_ok, password_hash

log=logging.getLogger('roomguard')
DATA=Path(os.environ.get('DATA_DIR','./data'));DATA.mkdir(parents=True,exist_ok=True)
engine=Engine(DATA/'monitor.db',os.environ.get('ADMIN_PASSWORD'))
sessions={}; failures=defaultdict(deque)
mqtt_client=None

def bridge_start():
    global mqtt_client
    import paho.mqtt.client as mqtt
    client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id='roomguard-server',clean_session=True)
    client.username_pw_set(os.environ.get('MQTT_USER','server'),os.environ.get('MQTT_PASSWORD',''))
    def connect(c,u,f,rc,props):
        engine.broker_online=rc==0
        if rc==0:
            for d in DEVICES:
                c.subscribe('building/'+d+'/state',1);c.subscribe('building/'+d+'/ack',1)
    def disconnect(c,u,flags,rc,props):engine.broker_online=False
    def message(c,u,msg):
        try:
            _,device,kind=msg.topic.split('/')
            if len(msg.payload)>8192:raise ValueError('payload too large')
            p=json.loads(msg.payload)
            if kind=='state':engine.ingest(device,p)
            elif kind=='ack':engine.ack(device,p)
        except Exception:log.exception('Rejected MQTT message on %s',msg.topic)
    client.on_connect=connect;client.on_disconnect=disconnect;client.on_message=message
    client.reconnect_delay_set(1,15)
    client.connect_async(os.environ.get('MQTT_HOST','127.0.0.1'),int(os.environ.get('MQTT_PORT','1883')),30)
    client.loop_start();mqtt_client=client
    def publish(device,p):
        info=client.publish('building/'+device+'/command',json.dumps(p),qos=1,retain=False)
        return info.rc==mqtt.MQTT_ERR_SUCCESS
    engine.publisher=publish

@asynccontextmanager
async def lifespan(app):
    if os.environ.get('DISABLE_MQTT')!='1':bridge_start()
    async def maintenance():
        n=0
        while True:
            engine.tick();n+=1
            if n%3600==0:engine.cleanup()
            if n%60==1:
                def trusted():
                    try:return subprocess.run(['timedatectl','show','-p','NTPSynchronized','--value'],capture_output=True,text=True,timeout=2).stdout.strip()=='yes'
                    except (OSError,subprocess.SubprocessError):return False
                if await asyncio.to_thread(trusted):engine.time_trusted=True
            # expire sessions and rate-limit bookkeeping with monotonic time
            for key in list(sessions):
                if sessions[key]<time.monotonic():del sessions[key]
            await asyncio.sleep(1)
    task=asyncio.create_task(maintenance())
    yield
    task.cancel()
    if mqtt_client:mqtt_client.loop_stop();mqtt_client.disconnect()

app=FastAPI(title='RoomGuard 局域网监控',lifespan=lifespan,docs_url=None,redoc_url=None)

@app.middleware('http')
async def headers(request,call_next):
    if request.headers.get('content-length','0').isdigit() and int(request.headers.get('content-length','0'))>16384:
        return Response(status_code=413)
    r=await call_next(request)
    r.headers['X-Content-Type-Options']='nosniff';r.headers['X-Frame-Options']='SAMEORIGIN'
    r.headers['Referrer-Policy']='same-origin'
    r.headers['Cache-Control']='no-store' if request.url.path.startswith('/api') else 'no-cache'
    return r

async def object_body(request):
    raw=await request.body()
    if len(raw)>16384:raise HTTPException(413,'请求过大')
    try:p=json.loads(raw)
    except (ValueError,UnicodeError):raise HTTPException(400,'无效JSON')
    if not isinstance(p,dict):raise HTTPException(400,'JSON对象必需')
    return p

def admin(request):
    token=request.headers.get('authorization','').removeprefix('Bearer ')
    if token not in sessions or sessions[token]<time.monotonic():raise HTTPException(401,'请登录或会话已过期')
    return 'admin'

def require_device(d):
    if d not in DEVICES:raise HTTPException(404,'设备不存在')

@app.get('/api/status')
def status():
    s=engine.snapshot();s['disk_free_mb']=shutil.disk_usage(DATA).free//1048576
    s['demo']=os.environ.get('DEMO')=='1'
    return s

@app.post('/api/login')
async def login(request:Request):
    body=await object_body(request);ip=request.client.host if request.client else 'local';now=time.monotonic()
    q=failures[ip]
    while q and now-q[0]>300:q.popleft()
    if len(q)>=10:raise HTTPException(429,'尝试过多，5分钟后重试')
    if body.get('username')!='admin' or not password_ok(str(body.get('password','')),engine.setting('admin_hash')):
        q.append(now);raise HTTPException(401,'账号或密码错误')
    q.clear();token=secrets.token_urlsafe(32);sessions[token]=now+8*3600
    return {'token':token,'expires_in':28800}

@app.post('/api/logout')
def logout(request:Request):
    token=request.headers.get('authorization','').removeprefix('Bearer ');sessions.pop(token,None)
    return {'ok':True}

@app.post('/api/password')
async def change_password(request:Request):
    actor=admin(request);p=await object_body(request)
    if not password_ok(str(p.get('old','')),engine.setting('admin_hash')):raise HTTPException(400,'原密码错误')
    new=p.get('new','')
    if not isinstance(new,str) or not 12<=len(new)<=128:raise HTTPException(400,'新密码须为12—128位')
    engine.set_setting('admin_hash',password_hash(new));sessions.clear()
    with engine.lock:engine.event('','password_changed',actor=actor);engine.db.commit()
    return {'ok':True}

@app.post('/api/nodes/{device}/{action}')
async def operate(device:str,action:str,request:Request):
    actor=admin(request);require_device(device);p=await object_body(request)
    try:
        if action=='confirm':engine.confirm(device,p.get('event_id',''),actor);return {'ok':True}
        if action=='silence':return engine.command(device,'silence',actor,p.get('event_id',''))
        if action=='config':return engine.command(device,'config',actor,clear_seconds=p.get('clear_seconds'))
        raise HTTPException(404,'操作不存在')
    except ValueError as e:raise HTTPException(409,str(e))

@app.get('/api/history')
def history(request:Request,kind:str='events',device:str|None=None,start:float=0,end:float|None=None,limit:int=1000):
    admin(request)
    try:return {'rows':engine.history(kind,device,start,end,limit)}
    except ValueError as e:raise HTTPException(400,str(e))

@app.get('/api/trend')
def trend(request:Request,device:str,start:float,end:float,points:int=240):
    admin(request)
    try:return engine.trend(device,start,end,points)
    except ValueError as e:raise HTTPException(400,str(e))

@app.get('/api/export')
def export(request:Request,kind:str='events',device:str|None=None,start:float=0,end:float|None=None):
    admin(request)
    try:data=engine.export(kind,device,start,end)
    except ValueError as e:raise HTTPException(400,str(e))
    return Response(data,media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="roomguard-'+kind+'.csv"'})

@app.get('/api/settings')
def settings(request:Request):
    admin(request);return {'retention':engine.setting('retention')}

@app.post('/api/settings')
async def update_settings(request:Request):
    actor=admin(request);p=await object_body(request)
    if any(type(p.get(k)) is not int or not 1<=p[k]<=3650 for k in ['samples','events']):raise HTTPException(400,'保存天数须为1—3650整数')
    engine.set_setting('retention',{k:p[k] for k in ['samples','events']})
    with engine.lock:engine.event('','retention_changed',actor=actor,detail=p);engine.db.commit()
    return {'ok':True}

@app.post('/api/time')
async def set_time(request:Request):
    actor=admin(request);p=await object_body(request);epoch=p.get('epoch')
    if type(epoch) not in (int,float) or not 1735689600<=epoch<=4102444800:raise HTTPException(400,'时间应在2025—2100年')
    if os.environ.get('ENABLE_CLOCK_SET')!='1':raise HTTPException(409,'管理员尚未安装或启用受限校时工具，见部署手册')
    before=time.time()
    try:
        subprocess.run(['sudo','-n','/usr/local/sbin/roomguard-set-time',str(int(epoch))],check=True,timeout=8,capture_output=True)
    except (OSError,subprocess.SubprocessError):raise HTTPException(503,'系统校时失败，请检查服务日志及受限校时工具')
    with engine.lock:engine.event('','clock_set',actor=actor,detail={'before':before,'after':time.time()});engine.db.commit()
    engine.time_trusted=True
    return {'ok':True,'server_time':time.time()}

@app.post('/api/demo/{device}')
async def demo(device:str,request:Request):
    admin(request);require_device(device)
    if os.environ.get('DEMO')!='1':raise HTTPException(404)
    p=await object_body(request)
    if type(p.get('smoke')) is not bool or type(p.get('flame')) is not bool:raise HTTPException(400,'bool required')
    engine.demo_inputs[device]=p
    return {'ok':True}

app.mount('/static',StaticFiles(directory=Path(__file__).parent/'static'),name='static')
@app.get('/')
def index():return FileResponse(Path(__file__).parent/'static'/'index.html')
