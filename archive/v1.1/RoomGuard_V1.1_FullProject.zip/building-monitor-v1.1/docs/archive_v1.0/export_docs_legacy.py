"""Build printable Word/PDF manuals from delivered Markdown (requires python-docx/reportlab)."""
from pathlib import Path
from xml.sax.saxutils import escape
from docx import Document
from docx.shared import Pt,Cm
from docx.oxml.ns import qn
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
root=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
normal=ParagraphStyle('cn',fontName='STSong-Light',fontSize=10,leading=16,wordWrap='CJK',spaceAfter=6)
heading=ParagraphStyle('h',parent=normal,fontSize=15,leading=22,spaceBefore=12,spaceAfter=9)
title=ParagraphStyle('title',parent=heading,fontSize=20,leading=28)
cell=ParagraphStyle('cell',parent=normal,fontSize=8,leading=12)
code=ParagraphStyle('code',parent=normal,fontSize=8,leading=12,backColor=colors.HexColor('#f0f4f8'),leftIndent=8,rightIndent=6,spaceAfter=0)
files=['开发部署手册','硬件装配与电路','架构与协议','比赛验收记录模板','交付与测试报告']
d=Document();sec=d.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.8)
for n in ['Normal','Title','Heading 1','Heading 2','Heading 3']:
 s=d.styles[n];s.font.name='Noto Sans CJK SC';s.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
d.styles['Normal'].font.size=Pt(10)
story=[]
d.add_heading('RoomGuard 项目开发与交付手册',0);d.add_paragraph('V1.0 · 完整源码、构建产物、硬件参考、部署及验收说明')
story+=[Paragraph('RoomGuard 项目开发与交付手册',title),Paragraph('V1.0 · 比赛首版',normal)]
for fi,name in enumerate(files):
 d.add_page_break();story.append(PageBreak());lines=(root/'docs'/f'{name}.md').read_text().splitlines();i=0;fenced=False
 while i<len(lines):
  line=lines[i]
  if line.startswith('```'):fenced=not fenced;i+=1;continue
  if fenced:
   d.add_paragraph(line,style='No Spacing');story.append(Paragraph(escape(line or ' '),code));i+=1;continue
  if not line.strip():story.append(Spacer(1,3));i+=1;continue
  if line.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    cs=[v.strip() for v in lines[i].strip('|').split('|')]
    if not all(set(v)<=set('-: ') for v in cs):rows.append(cs)
    i+=1
   t=d.add_table(rows=1,cols=len(rows[0]));t.style='Light Shading Accent 1'
   for j,v in enumerate(rows[0]):t.rows[0].cells[j].text=v
   for row in rows[1:]:
    cc=t.add_row().cells
    for j,v in enumerate(row):cc[j].text=v
   n=len(rows[0]);widths=[495/n]*n
   if n==2:widths=[145,350]
   pt=Table([[Paragraph(escape(v),cell) for v in r] for r in rows],colWidths=widths,repeatRows=1)
   pt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dce8f3')),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#c0ccda')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story+=[pt,Spacer(1,8)];continue
  if line.startswith('#'):
   level=len(line)-len(line.lstrip('#'));txt=line[level:].strip();d.add_heading(txt,min(level,3));story.append(Paragraph(escape(txt),title if level==1 else heading))
  else:d.add_paragraph(line);story.append(Paragraph(escape(line),normal))
  i+=1
# Add figures separately so code and protocol remain copyable in source files.
d.add_page_break();d.add_heading('系统架构与界面预览',1);story+=[PageBreak(),Paragraph('系统架构与界面预览',title)]
for file in [root/'docs/系统架构图.png',root/'artifacts/网页预览_桌面.png',root/'artifacts/网页预览_手机.png']:
 if file.exists():
  d.add_heading(file.stem,2);d.add_picture(str(file),width=Cm(16))
  from PIL import Image as PI
  im=PI.open(file);w,h=im.size;scale=min(495/w,630/h)
  story+=[Paragraph(file.stem,heading),Image(str(file),width=w*scale,height=h*scale),PageBreak()]
sec.footer.paragraphs[0].text='RoomGuard · V1.0 · 实物验收以测试记录为准'
d.save(root/'docs/项目开发与交付手册_V1.0.docx')
def page(c,doc):c.setFont('STSong-Light',9);c.drawRightString(550,25,f'RoomGuard V1.0 | {doc.page}')
SimpleDocTemplate(str(root/'docs/项目开发与交付手册_V1.0.pdf'),pagesize=(595.28,841.89),leftMargin=50,rightMargin=50,topMargin=42,bottomMargin=42).build(story,onFirstPage=page,onLaterPages=page)
print('Word/PDF generated')
