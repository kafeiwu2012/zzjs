#pragma once
// Copy to secrets.h. Replace values before flashing. Do not share secrets.h.
#define WIFI_SSID "CHANGE_ME"
#define WIFI_PASSWORD "CHANGE_ME"
#define MQTT_HOST "192.168.1.103"
#ifdef ESP32
#define DEVICE_ID "room101-esp32"
#define MQTT_PASSWORD "CHANGE_ME_101"
#else
#define DEVICE_ID "room102-esp8266"
#define MQTT_PASSWORD "CHANGE_ME_102"
#endif
// First-time MQ sensor aging must follow the actual manufacturer datasheet.
#define MQ_WARMUP_MS 180000UL // provisional runtime warm-up; validate experimentally
// ESP32 ADC millivolts measured at GPIO * external divider correction.
#define MQ_DIVIDER_RATIO 1.667f // example: upper10k/lower15k -> 5V becomes3V
// NodeMCU A0 board connector full scale: verify before using this provisional value.
#define ESP8266_A0_FULL_SCALE 3.2f
// Example: A0 external divider upper56k/lower10k -> 5V becomes0.758V.
#define ESP8266_MQ_DIVIDER_RATIO 6.6f
