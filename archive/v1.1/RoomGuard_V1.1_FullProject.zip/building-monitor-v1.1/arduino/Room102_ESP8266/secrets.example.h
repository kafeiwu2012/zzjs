#pragma once
// 请按实际网络和接线修改。不要公开真实密码。
#define WIFI_SSID "CHANGE_ME"
#define WIFI_PASSWORD "CHANGE_ME"
#define MQTT_HOST "192.168.1.103"
#define DEVICE_ID "room102-esp8266"
#define MQTT_PASSWORD "CHANGE_ME"
#define MQ_WARMUP_MS 180000UL // 开发默认，按模块资料及实测稳定时间调整
// 0=原型面包板(ESP32 AO10k/15k), 1=V1.1基板草案(ESP32 AO20k/10k)
// 只有实际按对应电路接线并核验后才切换。
#define HARDWARE_PROFILE 0
#if HARDWARE_PROFILE == 1
#define MQ_DIVIDER_RATIO 3.0f
#else
#define MQ_DIVIDER_RATIO 1.667f
#endif
#define ESP8266_A0_FULL_SCALE 3.2f // 必须核验本块板A0连接器量程
#define ESP8266_MQ_DIVIDER_RATIO 6.6f // 56k/10k保守分压
