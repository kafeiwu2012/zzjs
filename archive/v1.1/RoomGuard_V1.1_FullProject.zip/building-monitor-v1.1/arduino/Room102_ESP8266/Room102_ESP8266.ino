/* RoomGuard V1.1 - Arduino IDE 工程
 * 1. 选择匹配开发板与串口；2. 修改 secrets.h；3. 点击验证与上传。
 * 完整业务代码在同一窗口的 NodeRuntime.cpp 标签页。
 * .ino 与同名文件夹必须保持一致，其他文件不要拆开。
 */
#include <Arduino.h>
#ifndef ESP8266
#error "Select the correct ESP board for this room"
#endif
