from pathlib import Path
from pptx import Presentation
from PIL import Image,ImageDraw,ImageFont
import fitz,json
root=Path('/workspace/presentation');pdf=root/'previews/RoomGuard_中职竞赛项目展示_双人配合版.pdf'
p=fitz.open(pdf);print('PDF pages',len(p))
thumbs=[]
font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',18)
for i,page in enumerate(p):
 pix=page.get_pixmap(matrix=fitz.Matrix(1.3,1.3));path=root/'previews'/f'slide_{i+1:02d}.png';pix.save(path)
 im=Image.open(path).convert('RGB');im.thumbnail((480,270));tile=Image.new('RGB',(500,310),'#e1e7ee');tile.paste(im,((500-im.width)//2,8));ImageDraw.Draw(tile).text((15,281),f'{i+1:02d}',fill='#18354f',font=font);thumbs.append(tile)
for batch in range(2):
 sheet=Image.new('RGB',(2000,930),'#e1e7ee')
 for j,im in enumerate(thumbs[batch*12:(batch+1)*12]):sheet.paste(im,((j%4)*500,(j//4)*310))
 sheet.save(root/'previews'/f'contact_{batch+1}.png')
prs=Presentation('/workspace/deliverables/RoomGuard_中职竞赛项目展示_双人配合版.pptx')
issues=[]
for i,s in enumerate(prs.slides):
 for sh in s.shapes:
  if sh.left<0 or sh.top<0 or sh.left+sh.width>prs.slide_width+3000 or sh.top+sh.height>prs.slide_height+3000:issues.append((i+1,'geometry',sh.shape_id))
 if not s.notes_slide.notes_text_frame.text.strip():issues.append((i+1,'no notes'))
 # Collect rendered text: detect lower slide overflow or missing expected titles.
 for b in p[i].get_text('dict')['blocks']:
  for line in b.get('lines',[]):
   for span in line['spans']:
    if span['bbox'][3]>p[i].rect.height+1:issues.append((i+1,'rendered overflow',span['text']))
print('Issues',issues)
(root/'previews/检查结果.json').write_text(json.dumps({'slides':len(prs.slides),'notes':20,'geometry_issues':issues,'pdf_pages':len(p)},ensure_ascii=False,indent=2))
