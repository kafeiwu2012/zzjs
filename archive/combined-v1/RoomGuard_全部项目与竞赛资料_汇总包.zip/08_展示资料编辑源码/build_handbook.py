from pathlib import Path
import json
from docx import Document
from docx.shared import Pt,Cm
from docx.oxml.ns import qn
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from xml.sax.saxutils import escape
R=Path('/workspace/presentation');O=Path('/workspace/deliverables');slides=json.loads((R/'source/slide_notes.json').read_text())
intro='''# RoomGuard 双人展示与教师排练手册

适用对象：两名中职参赛学生及辅导教师。配套PPT为16页主讲＋4页答辩备页，16:9宽屏，已写入逐页演讲备注。主讲脚本约7分35秒，预留换页和停顿后约8分钟；以现场排练计时为准，不是硬性赛程承诺。

## 一、先完成三个替换

1. 封面填写学校、展示讲解学生姓名、硬件操作学生姓名；若需指导教师姓名，可在封面同一区域添加。
2. 本版第10、11页使用项目实际软件的模拟数据截图，并明确标注。完成实机联调后，可用自己的实测截图替换，并同步修改图注。
3. 第14页按当前交付日志列出软件验证。只有完成并保存实测记录后，才把目标机验收项改为“通过”，补上日期、设备、结果与证据。不要把“已编译”“已安装”“已测试”混为一谈。

## 二、两名学生怎样配合

A同学负责硬件与操作：识别传感器和引脚、电平量测、烧录、网络接入、观察声光、执行主讲口令并恢复设备。B同学负责展示与汇报：按房间说明数据归属，解释告警逻辑，指出界面变化及设计含义，回答与自己掌握内容相符的问题。

正常汇报时由B主讲，A安静关注设备。第13页进入演示时，B先给清楚口令，A再执行；看到状态后用点头或一句“操作完成”交接，不同时抢话。评委向A提问时，A直接回答自己做过的接线、测量和调试，B不必代答。

台面建议从左到右摆放101节点、102节点、路由器／树莓派，节点贴清晰房间标签。B站在屏幕一侧，A靠近设备，尽量不遮挡评委视线。演示关键点是“房间定位、状态变化、断网仍本地提醒”，不是展示繁多按钮。

## 三、第13页现场演示口令卡

| 时段 | B同学：口令与解读 | A同学：操作与观察 |
| --- | --- | --- |
| 0—15秒 | “请看101和102都在线，数据分别属于两个房间。” | 指向两块板与房间标签，确认绿色正常状态和页面在线 |
| 15—45秒 | “请触发101房间的测试异常。这里确认只表示已阅，消音后红灯仍保留。” | 使用提前排练的受控测试方式；观察声光；配合点击确认、消音，指出红灯保留 |
| 45—75秒 | “现在断开节点与服务器的通信，但不关闭节点电源。本地判断仍然运行。” | 执行事先验证的断网方式，保持节点供电；测试本地报警，等待约20秒服务器离线状态 |
| 75—90秒 | “请恢复连接，节点会重新上报当前状态。” | 恢复网络，核对节点上线；处理测试输入，按稳定时间恢复正常 |

操作方式要在赛前验证：路由器“禁用上网”可能只限制公网，未必阻断局域网MQTT，不能直接当作断网成功。可采用经过验证的局域网访问控制或测试网络方式；如果无法只隔离一个节点，必须按真实影响范围修改现场台词。不能拔掉ESP电源来证明“断网仍能报警”。

MQ-2需充分预热，真实气体／火焰测试须由教师按场地条件选择受控方式。若使用数字测试输入，只能证明对应软件与声光链路，不能替代物理传感器检出测试。现场限制不允许实物测试时，明确说明使用模拟界面或提前录制的实测视频；预录视频应保留实际录制证据，不冒充实时操作。

90秒是排练目标。若传感器响应、消音回执或重连未在预期时间内完成，B准确说明“正在等待状态确认”，不要说系统已经成功。可先解释原理，再根据实际状态继续。新增原因重新鸣叫和自动解除可作为加分演示，赛时不足时不强行加入。

## 四、三轮排练安排

第一轮：理解与识图。A能指出五类模块、VCC/GND/信号、5V与3.3V区别、两个ESP的不同接线；B能不看稿讲清完整数据链路和本地报警含义。两人都应理解“确认、消音、解除”的区别。

第二轮：操作与记录。在教师监督下完成供电、电平、预热、阈值和网络检查，逐项填写项目中的比赛验收记录模板；练习异常、断网、恢复，不靠背台词猜结果。

第三轮：计时与问答。按8分钟完整排练，记录每次延时和失败点；统一操作口令，减少临时换页。正式答辩前再做一遍服务器地址、节点在线、网页声音、APK后台设置与备用截图检查。

若赛程压缩到约5分钟，可隐藏第2、3、6、11、12页，其他页缩短说明，并将演示控制在60—70秒；保留架构、本地报警、断网、验证与效益。若有10分钟，可延长实机演示或讲一个实际故障排查案例，不必为了凑时长增加文字页。

## 五、答辩表达原则

用“我们做了什么—看到了什么—说明了什么”的句式。说出实际分工和测试过程，避免用“百分之百安全”“永不掉线”“完全替代消防”“已大规模应用”等无法证明的话。成本、效率和事故降低率没有实测时，只说明预期价值，不编造数字。

当前软件基础由辅助工具生成；学生参赛时应按实际完成的工作说明自己负责的理解、装配、参数配置、联调和测试，不把未独立编写的代码表述为全部自主编写。教师可在后续训练中补充学生实际修改及故障排查案例，使汇报更有个人经验。

## 六、常见问题与适合学生的回答

1. 为什么做这个项目？——我们想解决房间分散、巡查有间隔、异常位置不清楚的问题。系统补充持续监测与现场提醒能力。
2. 为什么用两种ESP？——首版正好有两种开发板，用它们验证不同硬件能够采用统一协议和房间管理方式，接线和ADC参数分别适配。
3. 为什么断网还能报警？——烟雾与火焰判断在节点本地完成，蜂鸣器和灯直接由节点控制，不等待服务器命令。
4. 温湿度超过阈值会报警吗？——当前需求不触发，只采集和展示。烟雾或火焰任意一项有效触发才启动环境报警。
5. 确认和消音有什么不同？——确认表示已看到；消音关闭本次蜂鸣器，但红灯和异常保留。只有恢复稳定达到设定时间才解除。
6. 消音后新增火焰怎么办？——新增原因取消本次消音并重新鸣叫；完全恢复后的新事件也重新报警。
7. 20秒是什么意思？——节点每5秒常规上报，服务器连续20秒未收到有效消息就判离线。这是设计超时，不是传感器检出时间。
8. MQ-2显示的是准确烟雾浓度吗？——不是。未经标定只能说明相对响应与阈值状态，不能把它标成准确ppm。
9. 5V模块为什么不能直接接ESP？——ESP GPIO使用3.3V电平。模拟量要分压并对应软件比例；数字量和蜂鸣器需要适合的电平转换。
10. 手机网页锁屏后会一直响吗？——不能靠网页保证。APK有原生后台服务，但仍需手机网络可达、系统允许后台运行，并通过指定OPPO真机测试。
11. 断网的数据会补回来吗？——首版只在重连后上报当前状态，没有完整补传。断网中发生又恢复的异常可能不进入服务器历史，后续考虑事件缓存。
12. 已经全部验证了吗？——软件测试和构建结果在第14页，目标机和实物验收按实际完成情况说明，尚未做过的明确说待测。
13. 项目有何经济效益？——可以利用已有路由器和浏览器，减少额外展示终端依赖。但具体成本和节省比例要按采购及使用记录核算。
14. 能直接用作正式消防系统吗？——不能。它是比赛教学演示原型，不能替代合规消防设施。
15. 后续怎样完善？——先完成整机实测，再考虑断网事件缓存、RTC时间保持、更多房间和更完善的安全管理。

## 七、PPT使用与编辑

PPT为16:9，可编辑文本与主要图形；屏幕截图保持为图片。Windows建议使用微软雅黑。进入PowerPoint“备注”区域可查看逐页讲稿与A同学操作提示，放映可用演讲者视图。教师也可直接打印本手册供两名学生分工练习。

第17—20页为备页，主讲第16页结束后不自动继续。PPT已将备页设为隐藏，正常放映跳过；答辩可在“查看所有幻灯片”中按问题打开，或取消隐藏。PDF预览包含全部20页，便于审阅。

下面是逐页讲稿。文字用于理解与排练，不要求逐字背诵；现场务必以实际状态为准。
'''
# speaker notes were generated with the presentation so titles and cues stay consistent
parts=[intro]
for row in slides:
 title=row['title'] or ('封面｜让异常被看见，让提醒到房间' if row['page']==1 else '结束｜让处置有依据')
 parts.append('\n## 第%d页｜%s\n\n%s\n'%(row['page'],title,row['notes']))
md='\n'.join(parts);(O/'双人演讲稿与教师排练手册.md').write_text(md)
# editable Word
D=Document();sec=D.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.8)
for name in ['Normal','Title','Heading 1','Heading 2']:
 st=D.styles[name];st.font.name='Microsoft YaHei';st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Microsoft YaHei')
D.styles['Normal'].font.size=Pt(10)
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
st=ParagraphStyle('cn',fontName='STSong-Light',fontSize=10,leading=16,wordWrap='CJK',spaceAfter=6)
h=ParagraphStyle('h',parent=st,fontSize=15,leading=22,spaceBefore=12,spaceAfter=8)
title=ParagraphStyle('t',parent=h,fontSize=20,leading=28)
cs=ParagraphStyle('cell',parent=st,fontSize=8,leading=12)
story=[];lines=md.splitlines();i=0
while i<len(lines):
 line=lines[i].strip()
 if not line:i+=1;continue
 if line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].strip().startswith('|'):
   cells=[a.strip() for a in lines[i].strip().strip('|').split('|')]
   if not all(set(c)<=set('-: ') for c in cells):rows.append(cells)
   i+=1
  table=D.add_table(rows=1,cols=3);table.style='Light Shading Accent 1'
  for j,c in enumerate(rows[0]):table.rows[0].cells[j].text=c
  for row in rows[1:]:
   rr=table.add_row()
   for j,c in enumerate(row):rr.cells[j].text=c
  t=Table([[Paragraph(escape(c),cs) for c in row] for row in rows],colWidths=[65,215,215],repeatRows=1)
  t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DFF5EE')),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#CBD7E0')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));story.extend([t,Spacer(1,8)]);continue
 if line.startswith('#'):
  level=len(line)-len(line.lstrip('#'));text=line[level:].strip()
  D.add_heading(text,0 if level==1 else 1)
  story.append(Paragraph(escape(text),title if level==1 else h))
 else:
  D.add_paragraph(line);story.append(Paragraph(escape(line),st))
 i+=1
sec.footer.paragraphs[0].text='RoomGuard · 双人竞赛展示排练手册 · 配合实际测试记录使用'
D.save(O/'双人演讲稿与教师排练手册.docx')
def page(c,doc):c.setFont('STSong-Light',9);c.drawRightString(550,24,f'RoomGuard · 排练手册 | {doc.page}')
SimpleDocTemplate(str(O/'双人演讲稿与教师排练手册.pdf'),pagesize=(595.28,841.89),leftMargin=50,rightMargin=50,topMargin=42,bottomMargin=40).build(story,onFirstPage=page,onLaterPages=page)
print('Speaker handbook written')
