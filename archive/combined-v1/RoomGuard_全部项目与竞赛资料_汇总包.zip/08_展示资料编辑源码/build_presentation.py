from pathlib import Path
from math import sin,cos,pi
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from PIL import Image
import json

ROOT=Path('/workspace/presentation');OUT=Path('/workspace/deliverables');ART=Path('/workspace/building-monitor/artifacts')
OUT.mkdir(exist_ok=True)
prs=Presentation();prs.slide_width=Inches(13.333);prs.slide_height=Inches(7.5)
prs.core_properties.title='RoomGuard 楼宇房间环境监测与异常声光告警系统｜竞赛汇报'
prs.core_properties.subject='中职学生竞赛展示 · 主讲与硬件操作双人配合'
prs.core_properties.author='项目指导团队'
C={'navy':'102C46','ink':'18354F','muted':'687F93','teal':'00A78F','mint':'DFF5EE','bg':'F3F6FA','white':'FFFFFF','line':'DCE5EC','orange':'F29A45','pale':'FFF0DE','red':'DC5560','pink':'FCE9EB','blue':'3F78D5','lightblue':'E8F0FC'}
notes=[]; titles=[];times=[]
def rgb(c):return RGBColor.from_string(C.get(c,c))
def rect(s,x,y,w,h,fill='white',line=None,r=0):
 sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
 sh.fill.solid();sh.fill.fore_color.rgb=rgb(fill)
 if line:sh.line.color.rgb=rgb(line);sh.line.width=Pt(1)
 else:sh.line.fill.background()
 if r:
  try:sh.adjustments[0]=r
  except:pass
 return sh

def circle(s,x,y,d,fill='teal',line=None):
 sh=s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d));sh.fill.solid();sh.fill.fore_color.rgb=rgb(fill)
 if line:sh.line.color.rgb=rgb(line)
 else:sh.line.fill.background()
 return sh

def txt(s,x,y,w,h,text,size=18,color='ink',bold=False,align=None):
 box=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=box.text_frame;tf.clear();tf.word_wrap=True
 tf.margin_left=tf.margin_right=0;tf.margin_top=tf.margin_bottom=0
 for i,line in enumerate(str(text).split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=1.17
  if align is not None:p.alignment=align
  for run in p.runs:
   run.font.name='Microsoft YaHei';run.font.size=Pt(size);run.font.bold=bold;run.font.color.rgb=rgb(color)
   rp=run._r.get_or_add_rPr();rp.set('lang','zh-CN');rp.set('altLang','en-US');ea=OxmlElement('a:ea');ea.set('typeface','Microsoft YaHei');rp.append(ea)
 return box

def ln(s,x1,y1,x2,y2,color='line',width=1.5,dash=False):
 sh=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));sh.line.color.rgb=rgb(color);sh.line.width=Pt(width)
 if dash:
  from pptx.enum.dml import MSO_LINE_DASH_STYLE
  sh.line.dash_style=MSO_LINE_DASH_STYLE.DASH
 return sh

def arrow(s,x,y,w=.45,color='teal'):
 sh=s.shapes.add_shape(MSO_SHAPE.CHEVRON,Inches(x),Inches(y),Inches(w),Inches(.22));sh.fill.solid();sh.fill.fore_color.rgb=rgb(color);sh.line.fill.background();return sh

def pill(s,x,y,w,label,fill='mint',color='teal',size=11):
 rect(s,x,y,w,.32,fill,r=.45);txt(s,x,y+.045,w,.23,label,size,color,True,PP_ALIGN.CENTER)

def icon(s,kind,x,y,z=.55,color='teal',bg=None):
 if bg:circle(s,x-.12,y-.12,z+.24,bg)
 def L(a,b,c,d):ln(s,x+a*z,y+b*z,x+c*z,y+d*z,color,2)
 def B(a,b,w,h):
  sh=rect(s,x+a*z,y+b*z,w*z,h*z,bg or 'white',color,r=.08);return sh
 if kind=='building':
  B(.15,.06,.7,.89)
  for yy in [.22,.43,.64]:
   for xx in [.29,.56]:rect(s,x+xx*z,y+yy*z,.12*z,.12*z,color)
  L(.05,.96,.95,.96)
 elif kind=='bell':
  L(.23,.63,.23,.36);L(.23,.36,.37,.17);L(.37,.17,.63,.17);L(.63,.17,.77,.36);L(.77,.36,.77,.63);L(.23,.63,.1,.78);L(.77,.63,.9,.78);L(.1,.78,.9,.78);L(.4,.94,.6,.94);L(.5,.04,.5,.17)
 elif kind=='wifi':
  for r in [.4,.25,.11]:
   last=None
   for j in range(13):
    a=pi*1.2+j*(pi*.6/12);pt=(.5+r*cos(a),.85+r*sin(a))
    if last:L(*last,*pt)
    last=pt
  circle(s,x+.45*z,y+.86*z,.10*z,color)
 elif kind=='screen':
  B(.04,.12,.92,.60);L(.5,.72,.5,.94);L(.28,.95,.72,.95)
 elif kind=='phone':B(.22,.03,.56,.94);L(.43,.85,.57,.85)
 elif kind=='server':
  for yy in [.08,.4,.72]:
   B(.12,yy,.76,.23);circle(s,x+.22*z,y+(yy+.08)*z,.065*z,color);L(.42,yy+.11,.73,yy+.11)
 elif kind=='sensor':
  B(.2,.2,.6,.6)
  for v in [.3,.5,.7]:L(v,.05,v,.2);L(v,.8,v,.95);L(.05,v,.2,v);L(.8,v,.95,v)
 elif kind=='clock':
  sh=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+.08*z),Inches(y+.08*z),Inches(.84*z),Inches(.84*z));sh.fill.background();sh.line.color.rgb=rgb(color);sh.line.width=Pt(2);L(.5,.25,.5,.53);L(.5,.53,.72,.62)
 elif kind=='check':L(.13,.5,.39,.77);L(.39,.77,.91,.19)
 elif kind=='doc':B(.17,.05,.66,.90);L(.3,.3,.68,.3);L(.3,.5,.68,.5);L(.3,.7,.6,.7)
 elif kind=='pin':
  sh=s.shapes.add_shape(MSO_SHAPE.TEAR,Inches(x+.17*z),Inches(y+.08*z),Inches(.64*z),Inches(.64*z));sh.rotation=135;sh.fill.solid();sh.fill.fore_color.rgb=rgb(color);sh.line.fill.background();circle(s,x+.38*z,y+.29*z,.2*z,bg or 'white')
 elif kind=='people':
  circle(s,x+.34*z,y+.05*z,.32*z,color);B(.18,.5,.64,.40)
 elif kind=='temp':
  B(.4,.08,.2,.60);circle(s,x+.25*z,y+.55*z,.5*z,color);rect(s,x+.465*z,y+.24*z,.07*z,.5*z,color)
 elif kind=='flame':
  sh=s.shapes.add_shape(MSO_SHAPE.TEAR,Inches(x+.2*z),Inches(y+.1*z),Inches(.6*z),Inches(.77*z));sh.rotation=225;sh.fill.solid();sh.fill.fore_color.rgb=rgb(color);sh.line.fill.background()
 elif kind=='db':
  sh=s.shapes.add_shape(MSO_SHAPE.CAN,Inches(x+.1*z),Inches(y+.05*z),Inches(.8*z),Inches(.9*z));sh.fill.solid();sh.fill.fore_color.rgb=rgb(bg or 'white');sh.line.color.rgb=rgb(color);sh.line.width=Pt(2)
 elif kind=='link':B(.02,.3,.4,.34);B(.58,.3,.4,.34);L(.3,.47,.7,.47)
 else:B(.16,.16,.68,.68);L(.3,.5,.7,.5)

def base(title,chapter,num,dark=False,subtitle=None):
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb('navy' if dark else 'bg')
 txt(s,.53,.28,8,.25,chapter,11,'teal' if not dark else 'B8E7E0',True)
 txt(s,10.6,.26,2.2,.3,'RoomGuard  /  V1.0',11,'muted' if not dark else 'A1B5C8',False,PP_ALIGN.RIGHT)
 if title:txt(s,.53,.85,12.2,.78,title,30,'white' if dark else 'ink',True)
 if subtitle:txt(s,.56,1.61,12,.42,subtitle,14,'muted' if not dark else 'B7C8D8')
 ln(s,.55,7.1,12.78,7.1,'line' if not dark else '2B465F',.7)
 txt(s,.55,7.19,10,.2,'楼宇房间环境监测与异常声光告警系统 · 比赛首版',9,'muted' if not dark else 'A1B5C8')
 txt(s,11.5,7.14,1.25,.25,(f'{num:02d} / 16' if num<=16 else f'备页 {num-16} / 4'),10,'muted' if not dark else 'A1B5C8',False,PP_ALIGN.RIGHT)
 titles.append(title);return s

def note(s,secs,script,ops='保持设备正常，关注主讲提示。',cue=''):
 n=f'建议时长：{secs}秒\nB同学｜展示讲解\n{script}\n\nA同学｜硬件操作\n{ops}\n\n配合提示\n{cue or "主讲结束本页后翻页；操作未完成时先确认状态。"}'
 s.notes_slide.notes_text_frame.text=n;notes.append(n);times.append(secs)

def cover_building(s,x,y):
 # Editable vector model: two rooms and one local alarm; no simulated physical test photo.
 rect(s,x,y,5.65,3.98,'193B57',r=.04);rect(s,x+.2,y+.2,5.25,.28,'284B66');txt(s,x+.4,y+.225,4,.2,'ROOMGUARD / BUILDING NETWORK',10,'A1B5C8',True)
 for i in range(2):
  xx=x+.35+i*2.55;fill='26465D' if i else '343C53';rect(s,xx,y+.78,2.35,2.52,fill,r=.04)
  pill(s,xx+.16,y+.95,.8,'101' if i==0 else '102','pink' if not i else 'mint','red' if not i else 'teal',15)
  for j in range(3):rect(s,xx+.18+j*.65,y+1.58,.48,.70,'38637C')
  icon(s,'sensor',xx+.25,y+2.55,.43,'B8D4E4',fill)
  icon(s,'bell',xx+1.48,y+2.48,.52,'red' if not i else 'teal',fill)
  txt(s,xx+.17,y+3.53,2.2,.25,'本地声光报警' if not i else '独立采集与上报',12,'B7C8D8')
 rect(s,x+.18,y+3.3,5.3,.10,'orange');ln(s,x+1.45,y+.65,x+4.05,y+.65,'teal',2)

def fit_pic(s,path,x,y,w,h,top=True):
 iw,ih=Image.open(path).size;sr=iw/ih;tr=w/h;pic=s.shapes.add_picture(str(path),Inches(x),Inches(y),width=Inches(w),height=Inches(h))
 if sr<tr:
  total=1-sr/tr;pic.crop_top=0 if top else total/2;pic.crop_bottom=total if top else total/2
 else:
  total=1-tr/sr;pic.crop_left=total/2;pic.crop_right=total/2
 return pic

def browser(s,path,x,y,w,h,label='实际软件界面 · 模拟数据'):
 rect(s,x,y,w,h,'white','line',.03);rect(s,x+.01,y+.01,w-.02,.30,'E5EDF4',r=.03)
 for i,col in enumerate(['red','orange','teal']):circle(s,x+.12+i*.15,y+.10,.07,col)
 txt(s,x+.7,y+.065,w-1,.2,label,9,'muted')
 fit_pic(s,path,x+.04,y+.33,w-.08,h-.38)

# 01
s=base('', '项目汇报  /  房间环境监测',1,True)
txt(s,.58,1.18,7,1.65,'让异常被看见\n让提醒到房间',40,'white',True)
txt(s,.62,3.15,6.3,.9,'楼宇房间环境监测与\n异常声光告警系统',23,'B9D2E4',True)
for x,w,t in [(.62,1.25,'双房间'),(2.02,1.65,'断网本地报警'),(3.82,1.55,'多终端管理')]:pill(s,x,4.42,w,t,'234A61','C4EEE5',11)
cover_building(s,7.05,1.45)
txt(s,.63,5.32,6,.72,'参赛学校：请填写\n展示讲解：请填写　　硬件操作：请填写',13,'A1B5C8')
txt(s,7.12,5.87,5.3,.3,'从房间现场，到管理工作台。',16,'white',True)
note(s,20,'各位评委老师好。我们展示的是楼宇房间环境监测与异常声光告警系统。我们的想法很直接：让房间里的异常能被及时看见，也让现场的人先听到提醒。接下来由我介绍项目，另一位同学配合进行硬件操作。','设备上电、MQ-2按实测要求预热；两个节点和管理界面保持正常。','先相互示意，再开始计时；封面姓名由老师替换。')

# 02
s=base('房间多、巡查难，异常不能只靠人发现','01  背景与问题',2,subtitle='以校园楼宇为例：宿舍、实训室、普通教室，都存在分散管理的房间。')
for i,(name,desc,kind,col) in enumerate([('宿舍','人员休息时，环境变化\n可能不易察觉','building','teal'),('实训室','设备与操作集中，\n需要关注环境异常','sensor','blue'),('普通教室','房间数量较多，\n人工巡查有时间间隔','screen','orange')]):
 x=.58+i*4.18;rect(s,x,2.32,3.99,3.15,'white',r=.06);icon(s,kind,x+.32,2.7,.66,col,'mint' if i==0 else 'lightblue' if i==1 else 'pale');txt(s,x+.32,3.64,3.2,.42,name,23,'ink',True);txt(s,x+.32,4.25,3.35,.82,desc,17,'muted')
rect(s,.58,5.85,12.18,.66,'navy',r=.08);txt(s,.85,6.02,11.6,.35,'需要补充的能力：持续感知、房间定位、现场提醒、集中管理。',19,'white',True)
note(s,25,'我们从校园里常见的场景出发。宿舍、实训室和教室分布在不同位置，人工巡查很难同时覆盖每个房间。所以我们希望增加一层持续监测：知道哪里出现异常，让现场先得到提醒，再把信息送到管理端。')

# 03
s=base('我们聚焦三个痛点','01  背景与问题',3,subtitle='不是只把数据传上来，还要让异常被发现、被定位、被处理。')
for i,(num,title,desc,kind) in enumerate([('01','发现有间隔','仅靠定时巡查，\n难以持续看到环境变化。','clock'),('02','位置不够清楚','只有“有异常”的提示，\n不便快速确认具体房间。','pin'),('03','网络中断怎么办','如果报警依赖服务器，\n断网就可能失去现场提醒。','wifi')]):
 x=.58+i*4.18;rect(s,x,2.38,3.99,3.57,'white',r=.05);txt(s,x+.27,2.58,.65,.6,num,34,'line',True);icon(s,kind,x+2.93,2.74,.52,'orange');txt(s,x+.3,3.62,3.35,.48,title,24,'ink',True);txt(s,x+.3,4.34,3.35,.98,desc,18,'muted')
txt(s,.66,6.3,11.8,.38,'设计取向：把报警能力留在房间，把管理信息汇到中心。',21,'teal',True)
note(s,25,'我们关注三个问题。第一，巡查有间隔；第二，异常要能定位到房间；第三，断网后不能把现场提醒也一起丢掉。因此方案把本地报警和集中管理分开，让它们互相配合。')

# 04
s=base('我们的目标：现场会报警，管理看得清','02  方案与目标',4)
for i,(value,unit,label,col) in enumerate([('2','间','房间独立定位','teal'),('5','秒','常规状态上报周期','blue'),('20','秒','未收到消息判定离线','orange')]):
 x=.62+i*4.18;rect(s,x,2.13,3.95,2.5,'white',r=.06);txt(s,x+.25,2.32,2,.95,value,61,col,True);txt(s,x+2.05,2.95,.9,.3,unit,20,'muted');txt(s,x+.27,3.74,3.43,.40,label,19,'ink',True)
rect(s,.62,4.99,12.11,1.1,'mint',r=.05);icon(s,'bell',.93,5.24,.48);txt(s,1.72,5.17,10.5,.62,'烟雾或火焰触发本地声光报警；异常变化即时上报。',23,'ink',True)
txt(s,.69,6.38,11.5,.35,'以上为首版设计参数，不代表已完成实物性能测量；温湿度仅采集展示。',12,'muted')
note(s,20,'首版只做两个房间，把关键链路做完整。常规状态每五秒上报，服务器连续二十秒没有收到有效消息就标记离线。烟雾或火焰触发后，不等下一次周期，立即上报告警。这里列出的是设计参数，实物时延还要通过现场测试确认。')

# 05
s=base('两间房，走通一套完整监测链路','02  系统架构',5,subtitle='房间节点 → 局域网 → 树莓派 → 展示与管理终端')
xs=[.57,3.83,6.32,9.57];ws=[2.82,2.06,2.81,3.18]
for x,w in zip(xs,ws):rect(s,x,2.22,w,3.74,'white',r=.04)
for i,(x,w,label) in enumerate(zip(xs,ws,['感知与本地报警','局域网传输','数据处理中心','多终端展示'])):
 pill(s,x+.15,2.41,w-.3,label,'mint' if i!=1 else 'lightblue','teal' if i!=1 else 'blue',12)
for j,(room,board) in enumerate([('101','ESP32'),('102','ESP8266')]):
 rect(s,.78,3.04+j*1.15,2.39,.95,'bg',r=.05);icon(s,'sensor',.95,3.26+j*1.15,.38);txt(s,1.53,3.13+j*1.15,1.5,.32,room+' 房间',19,'ink',True);txt(s,1.53,3.51+j*1.15,1.4,.25,board+' · 本地报警',10,'muted')
icon(s,'wifi',4.49,3.15,.65,'blue');txt(s,4.00,4.13,1.72,.75,'水星 MW305R\n2.4GHz Wi-Fi',15,'ink',True,PP_ALIGN.CENTER);txt(s,3.98,5.15,1.77,.3,'无需互联网',13,'teal',True,PP_ALIGN.CENTER)
icon(s,'server',7.40,3.03,.6);txt(s,6.56,3.91,2.33,.53,'Raspberry Pi 3B',18,'ink',True,PP_ALIGN.CENTER);txt(s,6.57,4.59,2.33,1.0,'MQTT 接入\n数据存储 / 状态处理\n权限与控制回执',14,'muted',False,PP_ALIGN.CENTER)
for j,(kind,t) in enumerate([('screen','大屏网页 · 只读'),('screen','电脑 / 平板网页'),('phone','手机网页 / APK'),('screen','Windows EXE')]):
 icon(s,kind,9.82,3.03+j*.65,.37,'blue');txt(s,10.42,3.07+j*.65,2.08,.30,t,13,'ink',j==0)
for a,b in [(3.41,3.78),(5.9,6.28),(9.15,9.53)]:arrow(s,a,4.00,b-a,'teal')
ln(s,.91,6.34,8.88,6.34,'orange',2);txt(s,1.0,6.46,8.1,.25,'反向控制：管理员确认 / 本次消音 / 配置下发 → 节点执行与回执',12,'muted');txt(s,9.65,6.3,3.0,.49,'所有终端通过同一局域网\n访问树莓派',11,'muted')
note(s,35,'系统分为四层。左边两个房间分别使用ESP32和ESP8266，传感器采集后先在本地判断。中间通过同一个路由器，把数据送到树莓派。树莓派负责存储、告警管理和权限，再分发给大屏、电脑和手机。管理员的消音或配置指令也通过服务器下发，并等待节点回执。')

# 06
s=base('两种 ESP，同一套房间管理方式','02  节点与模块',6,subtitle='101 使用 ESP32，102 使用 ESP8266；每个房间都配齐五类模块。')
rect(s,.6,2.22,3.40,3.9,'navy',r=.05)
for j,(room,board) in enumerate([('101 房间','ESP32'),('102 房间','ESP8266')]):
 icon(s,'sensor',.95,2.66+j*1.57,.64,'BEEBE1','navy');txt(s,1.94,2.68+j*1.57,1.75,.35,room,21,'white',True);txt(s,1.94,3.13+j*1.57,1.75,.31,board,16,'B7C8D8')
for j,(kind,name,detail,fill,col) in enumerate([('temp','DHT11','温湿度 · 只展示','lightblue','blue'),('sensor','MQ-2','烟雾／气体响应 · 参与报警','pale','orange'),('flame','火焰传感器','火焰相关信号 · 参与报警','pink','red'),('bell','有源蜂鸣器','低电平触发 · 声音提醒','mint','teal'),('sensor','RGB LED','正常绿灯 · 异常红闪','mint','teal')]):
 y=2.25+j*.77;rect(s,4.35,y,8.35,.64,'white',r=.08);icon(s,kind,4.58,y+.12,.35,col,fill);txt(s,5.16,y+.12,2.05,.31,name,17,'ink',True);txt(s,7.24,y+.14,5.14,.28,detail,15,'muted')
txt(s,.7,6.43,11.8,.32,'相同协议与告警规则；引脚、ADC量程和电平适配分别设计。',19,'teal',True)
note(s,25,'两个房间使用不同的ESP，但对管理端来说，采用一致的设备编号和告警含义。每个房间都有温湿度、烟雾和火焰采集，以及蜂鸣器和三色灯。温湿度只用于展示；烟雾和火焰才触发环境报警。两块板的引脚和模拟输入范围不同，不能直接照搬接线。')

# 07
s=base('报警在房间完成，服务器负责集中管理','03  核心机制',7)
for j,(kind,t,col) in enumerate([('sensor','烟雾阈值触发','orange'),('flame','火焰信号触发','red')]):
 y=2.41+j*1.2;rect(s,.62,y,2.8,.88,'white',r=.05);icon(s,kind,.84,y+.19,.44,col);txt(s,1.54,y+.23,1.75,.34,t,17,'ink',True)
ln(s,3.43,2.85,3.82,2.85,'teal',2);ln(s,3.43,4.05,3.82,4.05,'teal',2);ln(s,3.82,2.85,3.82,4.05,'teal',2);arrow(s,3.85,3.35,.44)
circle(s,4.4,2.97,1.05,'teal');txt(s,4.4,3.25,1.05,.4,'或',25,'white',True,PP_ALIGN.CENTER)
arrow(s,5.67,3.35,.42);rect(s,6.27,2.49,2.65,2.03,'navy',r=.05);icon(s,'sensor',7.26,2.78,.57,'BEEBE1','navy');txt(s,6.54,3.61,2.12,.61,'节点本地判断\n持续异常保持告警',15,'white',True,PP_ALIGN.CENTER)
arrow(s,9.07,3.35,.42);rect(s,9.65,2.49,3.02,2.03,'pink',r=.05);icon(s,'bell',10.82,2.77,.56,'red','pink');txt(s,9.9,3.60,2.52,.62,'蜂鸣器 + 红灯闪烁\n先提醒周围人员',16,'red',True,PP_ALIGN.CENTER)
rect(s,.64,5.14,4.4,.74,'lightblue',r=.06);icon(s,'temp',.88,5.30,.39,'blue','lightblue');txt(s,1.55,5.36,3.22,.34,'温湿度 → 上报，不触发报警',16,'blue',True)
ln(s,7.6,4.53,7.6,5.5,'teal',2);arrow(s,7.81,5.39,.4);txt(s,8.42,5.32,4.1,.7,'树莓派：记录、分发、管理\n网络不是本地报警的前提',17,'ink',True)
note(s,25,'这是最重要的一条逻辑：烟雾或者火焰，任意一项触发，房间节点就启动声光报警。两项同时触发，就显示两个原因。这个判断不需要服务器下命令。树莓派负责集中记录和通知，让本地提醒与远程管理各司其职。')

# 08
s=base('“确认”“消音”“解除”，是三件不同的事','03  告警闭环',8,subtitle='把状态说清楚，避免“关了声音就当作没有异常”。')
items=[('异常发生','声光报警\n记录房间与原因','red','pink'),('管理员确认','表示已经看到\n异常仍然保留','blue','lightblue'),('本次消音','蜂鸣器停止\n红灯与异常保留','orange','pale'),('稳定恢复','全部原因消失\n稳定 N 秒后解除','teal','mint')]
for i,(h,b,col,fill) in enumerate(items):
 x=.63+i*3.14;rect(s,x,2.62,2.85,2.40,'white',r=.05);circle(s,x+.25,2.88,.40,col);txt(s,x+.25,2.955,.4,.2,str(i+1),12,'white',True,PP_ALIGN.CENTER);txt(s,x+.25,3.58,2.36,.41,h,23,'ink',True);txt(s,x+.25,4.15,2.38,.64,b,16,'muted')
 if i<3:arrow(s,x+2.92,3.70,.16,'teal')
rect(s,.64,5.48,12.08,.67,'navy',r=.06);txt(s,.92,5.65,11.45,.35,'新增报警原因或出现新事件 → 重新鸣叫；N 默认 10 秒，可在管理端修改。',18,'white',True)
note(s,30,'我们特意区分三个操作。确认，只代表管理员看到了；消音，只关闭本次蜂鸣器，红灯和异常仍然保留。只有所有异常原因消失，并连续正常达到设定时间，告警才解除。如果消音后又增加了新的原因，系统会重新鸣叫，避免新的风险被旧消音覆盖。')

# 09
s=base('断网后，仍先提醒房间里的人','03  断网与恢复',9)
rect(s,.62,2.23,7.5,3.72,'navy',r=.05);txt(s,.94,2.53,6.8,.42,'房间现场：报警继续',26,'white',True)
icon(s,'sensor',1.22,3.43,.85,'BEEBE1','navy');arrow(s,2.47,3.76,.65);icon(s,'bell',3.48,3.43,.85,'orange','navy');arrow(s,4.73,3.76,.65);icon(s,'people',5.74,3.43,.85,'BEEBE1','navy')
for x,t in [(1.08,'传感器检测'),(3.38,'本地声光'),(5.64,'周围人员')]:txt(s,x,4.61,1.52,.34,t,16,'white',True,PP_ALIGN.CENTER)
icon(s,'wifi',6.77,2.65,.42,'muted','navy');ln(s,6.76,2.62,7.27,3.11,'red',3)
txt(s,.99,5.28,6.6,.31,'不依赖服务器下发报警命令',18,'BEEBE1',True)
rect(s,8.45,2.23,4.26,1.74,'white',r=.05);icon(s,'clock',8.73,2.56,.53,'orange');txt(s,9.57,2.49,2.83,.38,'服务器识别离线',20,'ink',True);txt(s,9.57,3.05,2.83,.55,'20 秒无有效消息\n显示最后数据时间与状态',14,'muted')
rect(s,8.45,4.19,4.26,1.76,'white',r=.05);icon(s,'link',8.73,4.53,.53);txt(s,9.57,4.45,2.83,.39,'联网恢复后',20,'ink',True);txt(s,9.57,5.0,2.83,.55,'立即上报当前状态\n恢复集中展示与管理',14,'muted')
txt(s,.72,6.40,11.8,.34,'首版边界：不补传断网期间的完整历史；断网中已发生并恢复的异常可能没有服务器记录。',12,'muted')
note(s,25,'网络断开时，房间里的人仍应该得到提醒，所以本地采集和声光继续运行。服务器超过二十秒没有收到消息，就标记离线，而不是继续显示正常。网络恢复后节点上报当前状态。首版还没有断网历史补传，因此我们不会声称每个离线事件都能被追溯。')

# 10
s=base('一套数据，覆盖大屏、电脑和手机','04  界面与管理',10,subtitle='同一数据源，按使用场景展示；管理操作需要登录。')
browser(s,ART/'网页预览_大屏.png',.61,2.18,8.10,4.35)
rect(s,9.05,2.18,1.83,4.35,'navy',r=.10);fit_pic(s,ART/'网页预览_手机.png',9.16,2.39,1.61,3.91)
for j,(h,t,col) in enumerate([('大屏','只读总览','teal'),('管理端','确认 / 消音','blue'),('APK','原生后台服务','orange')]):
 y=2.45+j*1.14;txt(s,11.15,y,1.6,.36,h,22,col,True);txt(s,11.15,y+.43,1.62,.58,t,13,'muted')
txt(s,.7,6.70,12,.21,'图为实际软件界面的模拟数据截图。EXE 使用 Edge 应用窗口；APK 已构建，后台／锁屏能力待 OPPO 真机验收。',10,'muted')
note(s,30,'这页是已经实现的软件界面，截图里的数据是模拟演示数据。大屏只读，电脑和手机登录后可以确认、消音和查看历史。Windows程序使用Edge独立窗口；手机APK除了前台页面，还有原生后台服务。不过OPPO锁屏后的效果仍要按真机测试结果报告。')

# 11
s=base('每一次异常，都应有记录可查','04  数据与追溯',11)
browser(s,ART/'网页预览_历史.png',.61,2.12,7.70,4.60,'实际历史界面 · 模拟数据')
for j,(value,label,desc,col) in enumerate([('30 天','常规采样保留','温湿度与烟雾相对响应','blue'),('180 天','事件与审计保留','发生 / 恢复 / 确认 / 消音','teal'),('CSV','按条件导出','便于复盘、整理和比赛记录','orange')]):
 y=2.17+j*1.50;rect(s,8.63,y,4.08,1.30,'white',r=.04);txt(s,8.87,y+.15,1.45,.52,value,25,col,True);txt(s,10.37,y+.17,2.12,.36,label,16,'ink',True);txt(s,8.9,y+.80,3.60,.27,desc,13,'muted')
txt(s,.7,6.80,12,.18,'保留时间为可调整默认值；MQ-2 曲线是相对响应，未经标定不标为 ppm。',10,'muted')
note(s,20,'系统不仅展示当前值，也保存历史。默认采样保留三十天，告警和操作记录保留一百八十天，并支持曲线与CSV导出，方便复盘。烟雾曲线表示传感器的相对响应，不把未经标定的数据写成准确的ppm浓度。')

# 12
s=base('把工程难点，落到接线、程序和测试里','05  工程实现',12)
cards=[('电平要匹配','5V 模块 ≠ 3.3V GPIO','MQ-2、电平转换、共地\n先量测，再连接 ESP','sensor','orange','pale'),('两种板要适配','ESP32 ≠ ESP8266','分别规划引脚与 ADC 量程\n统一上层协议与告警规则','link','blue','lightblue'),('网络不能拖住报警','异步网络 + 本地判断','采集与告警由主循环执行\n网络回调排入控制消息','wifi','teal','mint'),('旧手机要实测','Android 5.1 兼容','原生后台服务 + 运行设置\n用指定 OPPO 手机验收','phone','red','pink')]
for i,(h,k,b,ic,col,fill) in enumerate(cards):
 x=.63+(i%2)*6.22;y=2.19+(i//2)*2.12;rect(s,x,y,5.95,1.90,'white',r=.05);icon(s,ic,x+.30,y+.34,.56,col,fill);txt(s,x+1.21,y+.25,4.4,.35,h,23,'ink',True);txt(s,x+1.21,y+.81,4.4,.35,k,16,col,True);txt(s,x+1.21,y+1.25,4.4,.53,b,13,'muted')
note(s,30,'项目的难点不只在画面。五伏模块不能直接接三点三伏输入；两个ESP的引脚和ADC不同，需要分别适配。程序采用异步网络，避免等待服务器时拖住本地报警。旧手机则不能只看能不能安装，还要测试实际显示和后台运行。这些都是我们接下来装配调试的重点。')

# 13
s=base('现场演示：让评委看见三个关键场景','06  双人配合演示',13,subtitle='A 同学负责硬件操作，B 同学负责讲解定位、状态变化与设计含义。')
steps=[('01','双节点正常','两个房间同时上报\n房间编号与数据对应','sensor','teal'),('02','异常与处理','触发一个房间告警\n确认、消音，观察灯光保留','bell','red'),('03','断网仍报警','断开节点网络，保持供电\n看本地声光与服务器离线','wifi','orange')]
for i,(n,h,b,ic,col) in enumerate(steps):
 x=.62+i*4.18;rect(s,x,2.39,3.96,3.0,'white',r=.05);pill(s,x+.26,2.64,.60,n,'mint' if i==0 else 'pink' if i==1 else 'pale',col,12);icon(s,ic,x+2.92,2.72,.50,col);txt(s,x+.28,3.43,3.30,.45,h,24,'ink',True);txt(s,x+.28,4.13,3.38,.78,b,17,'muted')
rect(s,.64,5.77,12.07,.67,'navy',r=.06);txt(s,.93,5.95,11.5,.35,'演示配合：先口令 → 再操作 → 看状态 → 解释结果；完成后恢复正常连接。',18,'white',True)
note(s,90,'现在请看现场演示。首先，两个房间都在线，数据归属清楚。接下来请操作同学触发101房间的测试异常，我们同时观察本地声光和管理页面。确认只表示已看到，消音后红灯仍保留。最后断开102节点网络但保持供电，再测试本地异常。等待服务器识别离线时，可以看到本地报警不依赖网络。请操作同学恢复连接，我们观察状态恢复。','0—15秒：指示两个正常节点；15—45秒：受控触发101异常，配合确认与消音，展示灯光保留；45—75秒：断开102的网络而不切断电源，触发已排练的异常并等待约20秒离线显示；75—90秒：恢复网络并确认当前状态。现场条件不足时只能使用明确标识的模拟演示，不宣称为实物测试。','B说“请操作同学……”后A再动作。消音、新增原因和稳定解除可按赛时取舍。教师需提前确认场景能在90秒内稳定完成。')

# 14
s=base('验证结果分层说明，不把编译当作实测','07  验证与边界',14)
rect(s,.62,2.21,6.01,3.94,'white',r=.05);rect(s,6.90,2.21,5.81,3.94,'white',r=.05)
pill(s,.91,2.47,2.12,'已完成的软件验证','mint','teal',12);pill(s,7.19,2.47,2.13,'待完成的目标机验收','pale','orange',12)
for j,(num,t) in enumerate([('10 项','服务端自动测试通过'),('2 平台','ESP32 / ESP8266 固件编译通过'),('MQTT','真实本机代理 + 模拟节点联调通过'),('网页','桌面 / 手机 / 大屏浏览器测试通过')]):
 y=3.14+j*.62;txt(s,.94,y,1.33,.34,num,20,'teal',True);txt(s,2.38,y+.04,3.98,.31,t,15,'ink')
for j,t in enumerate(['树莓派 ARM64 部署与服务自启','电平、供电、预热与真实传感器触发','Windows 10 实机启动','OPPO 后台 / 锁屏及双节点长时间运行']):
 y=3.15+j*.63;circle(s,7.24,y+.11,.09,'orange');txt(s,7.49,y,4.92,.43,t,16,'ink')
txt(s,.72,6.48,11.9,.35,'证据来源：项目交付测试日志；本机 MQTT 测试使用模拟节点，尚未完成整机实物终验。',12,'muted')
note(s,25,'我们把验证分成两层。已经完成的包括十项服务端测试、两种固件编译、真实本机MQTT代理下的模拟节点联调，以及网页测试。还需要完成树莓派部署、电气量测、真实传感器和指定终端验收。只有做过、留有记录的测试，我们才把它写为通过。')

# 15
s=base('项目价值：从“看到数据”到“知道怎样处理”','08  效益与应用',15)
benefits=[('现场人员','增加就近提醒','异常时有声光提示\n断网仍保留本地能力','people','teal','mint'),('管理人员','更清楚地定位与追溯','按房间看异常、查历史\n确认与消音留有记录','pin','blue','lightblue'),('部署维护','利用现有局域网','复用路由器与浏览器\n核心运行不依赖公网','wifi','orange','pale'),('技能学习','训练完整工程过程','识图接线、烧录调试\n网络配置、测试与表达','doc','red','pink')]
for i,(aud,h,b,ic,col,fill) in enumerate(benefits):
 x=.62+i*3.14;rect(s,x,2.37,2.87,3.71,'white',r=.05);icon(s,ic,x+.28,2.75,.55,col,fill);txt(s,x+.28,3.54,2.36,.32,aud,15,col,True);txt(s,x+.28,4.02,2.36,.78,h,22,'ink',True);txt(s,x+.28,5.03,2.36,.69,b,14,'muted')
txt(s,.72,6.43,11.95,.33,'预期价值，不虚构节省比例或事故降低率；教学演示原型，不替代合规消防设施。',12,'muted')
note(s,20,'项目的价值有四个方面：现场多一层提醒，管理端能定位和追溯，部署可以利用现有局域网，同时也让我们训练从接线、烧录到测试和表达的完整技能。它目前是教学演示原型，不能替代合规消防设施，我们也不编造没有测量过的节省比例。')

# 16
s=base('', '汇报结束  /  请评委老师指导',16,True)
txt(s,.70,1.35,11.7,1.6,'让异常被看见\n让处置有依据',43,'white',True)
for i,(ic,h,b,col) in enumerate([('bell','房间自主报警','现场先得到提醒','orange'),('server','中心统一管理','异常定位到房间','BEEBE1'),('doc','过程留有记录','为复盘提供依据','8EB7F0')]):
 x=.76+i*4.20;icon(s,ic,x,4.15,.58,col,'navy');txt(s,x+.88,4.14,2.95,.42,h,24,'white',True);txt(s,x+.88,4.76,2.95,.37,b,16,'B7C8D8')
ln(s,.76,5.70,12.55,5.70,'2B465F',1);txt(s,.78,6.06,11.8,.40,'两名同学，一套系统：一人把操作做稳，一人把原理讲清。',22,'BEEBE1',True)
note(s,10,'我们的目标是让现场有提醒、管理有位置、事后有记录。汇报完毕，请各位评委老师指导。','将设备恢复到正常或已说明的状态；主讲结束后与B共同面向评委。','主讲结束，不主动翻到备页；按提问选择。')

# 17
s=base('答辩备页｜为什么采用这套架构？','答辩补充  /  技术选型',17)
for i,(ic,h,b,extra,col) in enumerate([('sensor','ESP：贴近现场','直接连接传感器与声光模块','本地判断不等待服务器','teal'),('server','树莓派：集中处理','在楼宇局域网内存储与管理','适合比赛中的轻量服务','blue'),('link','MQTT：设备消息通道','数据、事件、指令与回执分开','用户名与 ACL 限制主题权限','orange')]):
 x=.63+i*4.18;rect(s,x,2.29,3.96,3.77,'white',r=.05);icon(s,ic,x+.30,2.69,.66,col);txt(s,x+.3,3.67,3.34,.76,h,23,'ink',True);txt(s,x+.3,4.64,3.34,.77,b,16,'muted');txt(s,x+.3,5.45,3.34,.42,extra,13,col,True)
txt(s,.73,6.48,11.85,.34,'网页使用 2 秒轮询兼顾旧浏览器；安装完毕后，核心功能不需要互联网。',14,'muted')
note(s,0,'节点负责现场，树莓派负责集中管理，MQTT用于设备之间的消息传递。网页采用两秒轮询，是考虑旧安卓浏览器兼容性。这个规模的首版重点是把链路与故障处理走通，而不是声称已经支持大量设备。','按问题指向相应实物或界面，不重复整个演示。')

# 18
s=base('答辩备页｜5V 模块怎样接到 3.3V ESP？','答辩补充  /  电气接口',18)
rect(s,.63,2.25,12.06,1.43,'white',r=.05)
pill(s,.94,2.51,1.50,'MQ-2 · 5V','pale','orange',14);arrow(s,2.69,2.88,.48,'orange');rect(s,3.46,2.51,2.83,.75,'lightblue',r=.06);txt(s,3.57,2.70,2.60,.32,'AO：分压与量程换算',17,'blue',True,PP_ALIGN.CENTER);arrow(s,6.53,2.88,.48);rect(s,7.31,2.51,4.98,.75,'mint',r=.06);txt(s,7.5,2.70,4.6,.34,'ESP ADC：输入电压必须合规',18,'teal',True,PP_ALIGN.CENTER)
rect(s,.63,3.93,5.91,1.83,'white',r=.05);txt(s,.94,4.19,5.30,.4,'DO 与蜂鸣器：电平适配',23,'ink',True);txt(s,.95,4.86,5.24,.60,'BSS138 参考方案，低有效不反相\nLV=3.3V，HV=5V，信号共地',17,'muted')
rect(s,6.81,3.93,5.87,1.83,'white',r=.05);txt(s,7.12,4.19,5.25,.4,'ESP8266：先核验 A0',23,'ink',True);txt(s,7.13,4.86,5.25,.60,'开发板可能自带分压\n不能把芯片量程直接当作板接口量程',17,'muted')
txt(s,.75,6.29,11.9,.54,'参考设计未完成实物量测；具体阻值、极性与接线，以硬件手册及实测核验为准。',14,'orange',True)
note(s,0,'首先区分供电和信号电平。MQ-2用五伏供电，但ESP输入不能直接承受五伏。模拟输出通过分压，并在程序里使用对应比例；数字输出与蜂鸣器采用电平适配。ESP8266的A0还要核对板载分压，不能只凭外形猜量程。','若被追问，出示接线表和实际量测记录；没有量测的数据明确回答待测。')

# 19
s=base('答辩备页｜手机锁屏，为什么要有 APK？','答辩补充  /  终端兼容',19)
for i,(h,sub,col,fill,lines_) in enumerate([('手机网页','适合前台访问','blue','lightblue',['无需安装，局域网浏览器访问','前台查看、管理与声音提示','后台与锁屏受浏览器限制']),('Android APK','原生后台服务','teal','mint',['Android 5.1 最低版本声明','常驻服务、通知与 Wi-Fi 连接维护','需要 OPPO 真机测试与后台许可'])]):
 x=.64+i*6.22;rect(s,x,2.31,5.95,3.60,'white',r=.05);icon(s,'phone',x+.3,2.65,.54,col,fill);txt(s,x+1.2,2.63,4.4,.45,h,25,'ink',True);pill(s,x+1.2,3.18,2.28,sub,fill,col,12)
 for j,t in enumerate(lines_):circle(s,x+.37,4.03+j*.52,.07,col);txt(s,x+.62,3.94+j*.52,5.0,.35,t,16,'muted')
rect(s,.66,6.21,12.01,.51,'pale',r=.05);txt(s,.89,6.32,11.5,.33,'运行条件：手机能访问树莓派，应用被允许后台运行；断网或被强行停止后不能保证新告警。',13,'ink',True)
note(s,0,'网页能完成前台查看与管理，但浏览器后台可能暂停，因此锁屏告警不能只靠网页。APK增加原生后台服务和通知。当前安装包已经构建并验证签名，但指定OPPO手机能否持续后台运行，还要在开启后台许可后实测，不能承诺在断网或强停后仍能收新告警。')

# 20
s=base('答辩备页｜下一步，先验收，再扩展','答辩补充  /  完善计划',20)
for i,(n,h,b,col) in enumerate([('第一步','完成整机验收','电气与预热量测\n树莓派、Windows、OPPO\n双节点持续运行记录','teal'),('第二步','补强离线能力','有限事件缓存与补传\n考虑 RTC 独立时钟\n减少断网历史缺口','blue'),('第三步','扩展真实场景','按实测容量增加房间\n完善账号与网络安全\n持续校准与维护','orange')]):
 x=.63+i*4.18;rect(s,x,2.45,3.96,3.72,'white',r=.05);pill(s,x+.28,2.74,1.15,n,'mint' if i==0 else 'lightblue' if i==1 else 'pale',col,12);txt(s,x+.28,3.48,3.32,.52,h,25,'ink',True);txt(s,x+.28,4.40,3.32,1.17,b,18,'muted')
 if i<2:arrow(s,x+4.00,4.10,.14,col)
txt(s,.74,6.48,11.87,.30,'成本与效益按实际采购和测试记录核算，不把扩展设想写成已完成成果。',13,'muted')
note(s,0,'下一步首先完成整机验收，而不是急着增加功能。然后补强断网事件缓存与时间保持，最后根据实际容量增加节点并完善安全。采购成本与节省效益都应按实际记录核算。')

# Suppress default theme shadows for a clean flat visual style.
for slide_number,slide in enumerate(prs.slides,1):
 if slide_number>16:slide._element.set('show','0')
 for shape in slide.shapes:
  if hasattr(shape._element,'spPr'):
   spPr=shape._element.spPr
   for elem in list(spPr):
    if elem.tag.endswith('}effectLst') or elem.tag.endswith('}effectDag'):spPr.remove(elem)
   spPr.append(OxmlElement('a:effectLst'))
   for ref in shape._element.iter():
    if ref.tag.endswith('}effectRef'):ref.set('idx','0')
file=OUT/'RoomGuard_中职竞赛项目展示_双人配合版.pptx';prs.save(file)
(ROOT/'source/slide_notes.json').write_text(json.dumps([{'page':i+1,'title':t,'seconds':times[i],'notes':notes[i]} for i,t in enumerate(titles)],ensure_ascii=False,indent=2))
print(file,'slides=',len(prs.slides),'main seconds=',sum(times[:16]))
