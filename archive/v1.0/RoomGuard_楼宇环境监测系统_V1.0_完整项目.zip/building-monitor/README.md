# RoomGuard · 楼宇房间环境监测与异常声光告警

双房间比赛首版：101 ESP32、102 ESP8266、树莓派3B、MW305R局域网；三种网页场景、Windows10 EXE和Android5.1 APK。

从这里开始：

1. 阅读 `docs/交付与测试报告.md`，确认验证范围及待实物验收项。
2. 阅读 `docs/硬件装配与电路.md`，先量测电平，再接ESP。
3. 按 `docs/开发部署手册.md` 在树莓派安装服务、配置独立节点密码。
4. 运行 `python tools/configure_firmware.py`，再用PlatformIO编译和烧录。
5. 安装 `artifacts/` 中的EXE与APK，配置实际树莓派地址。
6. 按比赛验收清单完成真机联调。

快速看界面：安装 `server/requirements.txt` 后，在项目根目录运行 `python -m tools.run_demo`，访问 `http://127.0.0.1:8080`。仅模拟演示账号为admin / DemoOnly-123456；生产安装会要求设置自己的密码，不使用此账号密码。

重要边界：

- 交付BIN使用占位Wi-Fi/MQTT凭据，必须本地配置并重编译后才能接入。
- EXE需要Windows10 x64及系统Microsoft Edge；以Edge应用窗口呈现统一管理界面。
- APK为开发签名版，已检查minSdk22和v1签名；尚未在OPPO真机验收。
- 节点本地独立报警；首版断网后仅重连上报当前状态，不补传历史。
- 温湿度不触发报警；MQ响应非标定ppm。
- HTTP/MQTT只面向可信比赛局域网；完整实物、电气和后台保活测试不能由软件编译替代。

详见docs中的完整手册、协议、任务需求书及测试报告。未在用户的树莓派上执行部署。
