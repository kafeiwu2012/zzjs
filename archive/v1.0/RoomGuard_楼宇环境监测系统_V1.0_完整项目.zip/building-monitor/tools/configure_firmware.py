"""Create local secrets.h without committing passwords. Run before PlatformIO build."""
from pathlib import Path
import getpass,json
root=Path(__file__).resolve().parents[1]
def string(name,value):return '#define '+name+' '+json.dumps(value,ensure_ascii=True)+'\n'
ssid=input('2.4GHz Wi-Fi SSID: ').strip();wifi=getpass.getpass('Wi-Fi password: ')
host=input('Raspberry Pi IPv4: ').strip()
import ipaddress
ipaddress.IPv4Address(host)
p101=getpass.getpass('MQTT room101-esp32 password: ');p102=getpass.getpass('MQTT room102-esp8266 password: ')
if not ssid or min(len(p101),len(p102))<12:raise SystemExit('SSID不能为空，节点密码至少12位')
scale=float(input('ESP8266 A0开发板连接器满量程V（实测，常见3.2；芯片裸ADC为1.0）: '))
if not 0.8<=scale<=3.6:raise SystemExit('请核验A0量程')
s='#pragma once\n'+string('WIFI_SSID',ssid)+string('WIFI_PASSWORD',wifi)+string('MQTT_HOST',host)
s+='#ifdef ESP32\n'+string('DEVICE_ID','room101-esp32')+string('MQTT_PASSWORD',p101)+'#else\n'+string('DEVICE_ID','room102-esp8266')+string('MQTT_PASSWORD',p102)+'#endif\n'
s+='#define MQ_WARMUP_MS 180000UL\n#define MQ_DIVIDER_RATIO 1.667f\n#define ESP8266_A0_FULL_SCALE '+str(scale)+'f\n#define ESP8266_MQ_DIVIDER_RATIO 6.6f\n'
p=root/'firmware/include/secrets.h';p.write_text(s);p.chmod(0o600)
print('已写入本地secrets.h；预热180秒为待实测默认值，正式比赛前按器件资料和稳定性结果调整。')
