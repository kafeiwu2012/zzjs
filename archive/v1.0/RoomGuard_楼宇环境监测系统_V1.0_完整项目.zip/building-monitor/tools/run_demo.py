"""Explicit simulated devices; data directory is separate from production."""
import os,threading,time,uuid
os.environ.setdefault('ADMIN_PASSWORD','DemoOnly-123456')
os.environ.setdefault('DATA_DIR','./demo-data')
os.environ['DISABLE_MQTT']='1';os.environ['DEMO']='1'
from server.app import engine
from server.core import DEVICES
engine.time_trusted=True
engine.demo_inputs={d:{'smoke':False,'flame':False} for d in DEVICES}
states={}
for i,d in enumerate(DEVICES):
 states[d]={'boot':uuid.uuid4().hex[:8],'seq':0,'event_id':'','active':False,'muted':False,'reasons':[],'smoke':False,'flame':False,'dht_ok':True,'mq_ready':True,'temperature':24+i,'humidity':55+i,'mq_raw':120,'mq_voltage':.5,'config_version':0}

def publish(d,p):
 s=states[d]
 if p['kind']=='silence':s['muted']=True
 else:s['config_version']=p['version']
 engine.ack(d,{'id':p['id'],'status':'applied'})
 return True
engine.publisher=publish;engine.broker_online=True

def loop():
 while True:
  for d,s in states.items():
   old=s['reasons'];p=engine.demo_inputs[d];reasons=[k for k in ['smoke','flame'] if p[k]]
   if reasons and not s['active']:s['event_id']=uuid.uuid4().hex;s['active']=True;s['muted']=False
   if any(k not in old for k in reasons):s['muted']=False
   # demo supports the same stable-normal clear interval
   if s['active'] and not reasons:
    s.setdefault('_clear',time.monotonic())
    if time.monotonic()-s['_clear']>=engine.setting('config:'+d)['clear_seconds']:s['active']=False;s['muted']=False
   else:s.pop('_clear',None)
   s['reasons']=reasons;s.update(p);s['seq']+=1
   s['mq_raw']=1800 if p['smoke'] else 120
   engine.ingest(d,{k:v for k,v in s.items() if not k.startswith('_')})
  time.sleep(1)
threading.Thread(target=loop,daemon=True).start()
if __name__=='__main__':
 import uvicorn
 uvicorn.run('server.app:app',host='127.0.0.1',port=8080)
