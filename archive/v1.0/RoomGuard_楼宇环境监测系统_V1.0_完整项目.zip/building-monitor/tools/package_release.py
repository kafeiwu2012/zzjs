from pathlib import Path
import hashlib,shutil,zipfile,json
root=Path(__file__).resolve().parents[1];out=root.parent/'deliverables';out.mkdir(exist_ok=True)
skip_dirs={'.venv','.platformio','.pio','__pycache__','.pytest_cache','.git','.gradle','build','data','demo-data'}
def include(p):
 rel=p.relative_to(root)
 return not any(part in skip_dirs for part in rel.parts) and p.name not in {'secrets.h','.env'} and p.suffix not in {'.jks','.keystore','.pdb','.idsig','.pyc'} and p.name!='SHA256SUMS.txt'
files=sorted(p for p in root.rglob('*') if p.is_file() and include(p))
sums=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files)
(root/'artifacts/SHA256SUMS.txt').write_text(sums)
archive=out/'RoomGuard_楼宇环境监测系统_V1.0_完整项目.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in files+[root/'artifacts/SHA256SUMS.txt']:z.write(p,'building-monitor/'+p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert not any('/secrets.h' in n or n.endswith('.jks') or '/.venv/' in n for n in z.namelist())
 print('Files:',len(z.namelist()),'Archive:',archive.stat().st_size)
for name in ['项目开发与交付手册_V1.0.docx','项目开发与交付手册_V1.0.pdf']:
 shutil.copy(root/'docs'/name,out/name)
for name in ['RoomGuard-Windows10-x64.exe','RoomGuard-Android5.1.apk','网页预览_桌面.png']:
 shutil.copy(root/'artifacts'/name,out/name)
shutil.copy(root/'docs/交付与测试报告.md',out/'交付与测试报告.md')
(out/'项目压缩包_SHA256.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print('Release integrity and secret exclusion checks passed')
